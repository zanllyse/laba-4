from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        username = request.form['username']
        comment = request.form['comment']
        new_feedback = Feedback(username=username, comment=comment)
        db.session.add(new_feedback)
        db.session.commit()
        return redirect(url_for('feedback'))
    feedbacks = Feedback.query.all()
    return render_template('feedback.html', feedbacks=feedbacks)
@app.route('/admin/feedback', methods=['GET', 'POST'])
def admin_feedback():
    if request.method == 'POST':
        feedback_id = request.form['feedback_id']
        feedback_to_delete = Feedback.query.get(feedback_id)
        db.session.delete(feedback_to_delete)
        db.session.commit()
    feedbacks = Feedback.query.all()
    return render_template('admin_feedback.html', feedbacks=feedbacks)
@app.route('/admin/products', methods=['GET', 'POST'])
def admin_products():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        new_product = Product(name=name, price=price)
        db.session.add(new_product)
        db.session.commit()
    products = Product.query.all()
    return render_template('admin_products.html', products=products)
@app.route('/admin/orders', methods=['GET', 'POST'])
def admin_orders():
    if request.method == 'POST':
        order_id = request.form['order_id']
        new_status = request.form['status']
        order = Order.query.get(order_id)
        order.status = new_status
        db.session.commit()
    orders = Order.query.all()
    return render_template('admin_orders.html', orders=orders)

