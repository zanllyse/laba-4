# laba-4
python -m venv venv
flask_shop/
├── app.py
├── models.py
├── templates/
│   ├── feedback.html
│   ├── admin_feedback.html
│   ├── admin_products.html
│   └── admin_orders.html
└── static/

